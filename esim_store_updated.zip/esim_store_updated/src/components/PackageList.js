
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function PackageList({ country }) {
    const [packages, setPackages] = useState([]);

    useEffect(() => {
        const fetchPackages = async () => {
            try {
                const response = await axios.post('https://your-server.com/api/packages', { country });
                setPackages(response.data.obj.packageList);
            } catch (error) {
                console.error('Error fetching packages:', error);
            }
        };
        fetchPackages();
    }, [country]);

    const handlePurchase = async (pkg) => {
        const transactionId = `TXN-${Date.now()}`;
        try {
            const response = await axios.post('https://your-server.com/api/purchase', {
                packageCode: pkg.packageCode,
                count: 1,
                transactionId: transactionId,
            });
            alert(`Purchase successful! Order Number: ${response.data.obj.orderNo}`);
        } catch (error) {
            console.error('Error purchasing package:', error);
            alert('Purchase failed');
        }
    };

    return (
        <div>
            <h2>Packages for {country}</h2>
            <ul>
                {packages.map(pkg => (
                    <li key={pkg.packageCode}>
                        {pkg.name} - {pkg.price / 10000} USD - {pkg.volume / 1024 / 1024} MB
                        <button onClick={() => handlePurchase(pkg)}>Buy</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default PackageList;
