
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function OrderDetails({ orderNo }) {
    const [orderDetails, setOrderDetails] = useState(null);

    useEffect(() => {
        const fetchOrderDetails = async () => {
            try {
                const response = await axios.post('https://your-server.com/api/order', { orderNo });
                setOrderDetails(response.data.obj.esimList);
            } catch (error) {
                console.error('Error fetching order details:', error);
            }
        };
        fetchOrderDetails();
    }, [orderNo]);

    return (
        <div>
            {orderDetails ? (
                <div>
                    <h3>Order Details</h3>
                    <pre>{JSON.stringify(orderDetails, null, 2)}</pre>
                </div>
            ) : (
                <p>Loading...</p>
            )}
        </div>
    );
}

export default OrderDetails;
